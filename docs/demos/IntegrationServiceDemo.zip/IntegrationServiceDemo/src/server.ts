import { Type } from './di.type';
import { container } from './di.config';
import { AppConfig } from './config/app-config'; // eslint-disable-line no-unused-vars
import { AppLogger } from './lib/logger/app-logger'; // eslint-disable-line no-unused-vars

import {
  SystemService, // eslint-disable-line no-unused-vars
  ServiceConfiguration, // eslint-disable-line no-unused-vars
  Level, // eslint-disable-line no-unused-vars
  MessageConsumer, // eslint-disable-line no-unused-vars
} from 'system-service';
import { DemoConsumer } from './demo-consumer'; // eslint-disable-line no-unused-vars
import { DemoService } from './demo-service'; // eslint-disable-line no-unused-vars

async function start() {
  const appConfig = container.get<AppConfig>(Type.AppConfig).config();
  const logger = container.get<AppLogger>(Type.AppLogger);
  logger.isApplyMessageFormat = true;

  logger.log(`Welcome to '${appConfig.name}'`);

  /*
  const demoConsumer: DemoConsumer = container.get<MessageConsumer>(Type.MessageConsumer);
  const serviceConfig: ServiceConfiguration = container.get<ServiceConfiguration>(Type.ServiceConfiguration);
  const service: SystemService = new SystemService(serviceConfig, demoConsumer); // Using SystemService directly
  service.start();
  */

  const demoService: DemoService = container.get<SystemService>(
    Type.SystemService,
  ); // Create custom Service
  demoService.start();
}

start();
