import { decorate, inject, injectable } from 'inversify';
import { Type } from './di.type';

import { ServiceConfig } from './config/service-config'; // eslint-disable-line no-unused-vars
import { SystemService, MessageConsumer } from 'system-service'; // eslint-disable-line no-unused-vars
decorate(injectable(), SystemService);

@injectable()
export class DemoService extends SystemService {
  constructor(
    @inject(Type.ServiceConfiguration) config: ServiceConfig,
    @inject(Type.MessageConsumer) messageConsumer: MessageConsumer,
  ) {
    super(config, messageConsumer);
  }
}
