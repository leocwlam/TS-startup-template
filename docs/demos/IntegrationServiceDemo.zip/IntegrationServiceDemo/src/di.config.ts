import { Container } from 'inversify';
import 'reflect-metadata';
import { Type } from './di.type';

import { AppConfig } from './config/app-config';
import { AppLogger } from './lib/logger/app-logger';
import { DemoConsumer } from './demo-consumer'; // eslint-disable-line no-unused-vars
import { DemoService } from './demo-service'; // eslint-disable-line no-unused-vars
import { ServiceConfig } from './config/service-config'; // eslint-disable-line no-unused-vars
import {
  SystemService, // eslint-disable-line no-unused-vars
  ServiceConfiguration, // eslint-disable-line no-unused-vars
  MessageConsumer, // eslint-disable-line no-unused-vars
} from 'system-service';

// Need to define MessageConsumer for injectable

export const container = new Container();
container.bind<AppConfig>(Type.AppConfig).to(AppConfig);
container.bind<AppLogger>(Type.AppLogger).to(AppLogger);
container.bind<MessageConsumer>(Type.MessageConsumer).to(DemoConsumer);
container
  .bind<ServiceConfiguration>(Type.ServiceConfiguration)
  .to(ServiceConfig);
container.bind<SystemService>(Type.SystemService).to(DemoService);

// eslint-disable-next-line no-console
container.bind(Type.ExternalLogger).toFunction(console.log);
