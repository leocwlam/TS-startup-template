export const Type = {
  AppConfig: Symbol('AppConfig'),
  AppLogger: Symbol('AppLogger'),
  ExternalLogger: Symbol('ExternalLogger'),
  MessageConsumer: Symbol('MessageConsumer'),
  ServiceConfiguration: Symbol('ServiceConfiguration'),
  SystemService: Symbol('SystemService'),
};
