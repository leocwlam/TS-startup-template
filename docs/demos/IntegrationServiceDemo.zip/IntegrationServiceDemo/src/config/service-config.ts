import { injectable } from 'inversify';

// import * as APPCONFIG from '../app-config.json';
// // eslint-disable-next-line no-unused-vars
// import { Config } from './config';

import { ServiceConfiguration, Level } from 'system-service'; // eslint-disable-line no-unused-vars

// const config: ServiceConfiguration = { log: { config: { level: level.error } } };

@injectable()
export class ServiceConfig implements ServiceConfiguration {
  log!: { config: { level: Level.error } };
}
