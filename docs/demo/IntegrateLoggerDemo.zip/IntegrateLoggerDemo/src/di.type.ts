export const Type = {
  AppConfig: Symbol('AppConfig'),
  LoggerConfiguration: Symbol('LoggerConfiguration'),
  AppLogger: Symbol('AppLogger'),
  ExternalLogger: Symbol('ExternalLogger'),
};
