import { inject, injectable } from 'inversify';
import { Type } from '../../di.type';
// eslint-disable-next-line no-unused-vars
import { LoggerConfiguration, Logger as SystemLogger } from 'system-logger';
// eslint-disable-next-line no-unused-vars
import { Level } from './logger';
import { AppLogger } from './app-logger';

@injectable()
export class SampleLogger extends AppLogger {
  private logger: SystemLogger;

  public constructor(
    @inject(Type.LoggerConfiguration) loggerConfig: LoggerConfiguration,
  ) {
    super();
    this.logger = new SystemLogger(loggerConfig);
  }

  private systemLogLevel(level: Level) {
    switch (level) {
      case Level.error:
        return 'error';
      case Level.warn:
        return 'warn';
      case Level.info:
        return 'info';
      case Level.verbose:
        return 'verbose';
      case Level.debug:
        return 'debug';
      case Level.silly:
        return 'silly';
    }

    return 'info';
  }

  protected execute(level: Level, message: string, optional?: any): void {
    this.logger.log(this.systemLogLevel(level), message, optional);
  }
}
