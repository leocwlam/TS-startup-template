export interface Config {
  load(): void;
  config(): any;
}
