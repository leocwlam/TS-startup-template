import { Container } from 'inversify';
import 'reflect-metadata';
import { Type } from './di.type';

import { SampleLogger } from './lib/logger/sample-logger';

import { AppConfig } from './config/app-config';
import { LoggerConfig } from './config/logger-config';
// import { AppLogger } from './lib/logger/app-logger';

export const container = new Container();
container.bind<AppConfig>(Type.AppConfig).to(AppConfig);
container.bind<LoggerConfig>(Type.LoggerConfiguration).to(LoggerConfig);
// container.bind<AppLogger>(Type.AppLogger).to(AppLogger);
container.bind<SampleLogger>(Type.AppLogger).to(SampleLogger);
// eslint-disable-next-line no-console
container.bind(Type.ExternalLogger).toFunction(console.log);
