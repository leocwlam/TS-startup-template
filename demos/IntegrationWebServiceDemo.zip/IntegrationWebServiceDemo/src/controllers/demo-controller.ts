/* eslint-disable no-unused-vars */
import { injectable } from 'inversify';
import { Request, Response } from 'express';

import { Demo } from '../models/demo';

/**
 * @swagger
 * tags:
 * - name: Demo
 *   description: Everything about Demo
 *   externalDocs:
 *     description: Find out more
 *     url: https://github.com/leocwlam/TS-startup-template/wiki/Integration#setup-the-project-as-web-service-with-express-npm
 */
@injectable()
export class DemoController {
  private crashDemos = new Map<number, Demo>();

  private getDemos(request: Request, response: Response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Content-Type', 'application/json');

    const demos: Demo[] = Array.from(this.crashDemos.values());
    return response.status(200).end(JSON.stringify(demos));
  }

  private getDemo(id: number, response: Response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Content-Type', 'application/json');

    const demo = this.crashDemos.get(id);
    return response.status(200).end(JSON.stringify(demo));
  }

  private saveDemo(request: Request, response: Response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Content-Type', 'application/json');

    const demo = Object.assign(new Demo(), {
      id: Number(request.body.id),
      name: request.body.name,
    });
    this.crashDemos.set(demo.id, demo);
    return response.status(201).end(JSON.stringify(demo));
  }

  private editDemo(id: number, request: Request, response: Response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Content-Type', 'application/json');

    const editId: number = Number(request.body.id);
    if (id !== editId) {
      return response.status(415).end(JSON.stringify('id does not match.'));
    }
    if (!this.crashDemos.has(id)) {
      return response.status(415).end(JSON.stringify('demo does not exist.'));
    }
    const demo = Object.assign(new Demo(), {
      id: editId,
      name: request.body.name,
    });
    this.crashDemos.set(id, demo);
    return response.status(200).end(JSON.stringify(demo));
  }

  private deleteDemo(id: number, response: Response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Content-Type', 'application/json');

    if (this.crashDemos.has(id)) {
      this.crashDemos.delete(id);
    }
    return response.status(200).end();
  }

  uriMapping(app: any) {
    /**
     * @swagger
     * /demos:
     *   get:
     *     tags:
     *       ['Demo']
     *     summary: Find demos.
     *     description: Demo list.
     *     consumes:
     *       - application/json
     *     responses:
     *       200:
     *         description: OK
     *         schema:
     *           type: array
     *           items:
     *             $ref: '#/definitions/Demo'
     */
    app.get('/demos', (request: Request, response: Response) => {
      this.getDemos(request, response);
    });

    /**
     * @swagger
     * /demo/{id}:
     *   get:
     *     tags:
     *       ['Demo']
     *     summary: Find demo by id.
     *     description: Getting demo with id.
     *     consumes:
     *       - application/json
     *     parameters:
     *       - in: path
     *         name: id
     *         description: Demo id
     *         required: true
     *         schema:
     *           type: integer
     *           minimum: 1
     *     responses:
     *       200:
     *         description: OK
     *         schema:
     *           $ref: '#/definitions/Demo'
     */
    app.get('/demo/:id', (request: Request, response: Response) => {
      return this.getDemo(Number(request.params.id), response);
    });

    /**
     * @swagger
     * /demo:
     *   post:
     *     tags:
     *       ['Demo']
     *     summary: Save new demo.
     *     description: Save demo.
     *     consumes:
     *       - application/json
     *     parameters:
     *       - in: body
     *         name: body
     *         description: Demo object that needs to be added to the memory.
     *         required: true
     *         schema:
     *           $ref: '#/definitions/Demo'
     *     responses:
     *       201:
     *         description: OK
     *         schema:
     *           $ref: '#/definitions/Demo'
     */
    app.post('/demo', (request: Request, response: Response) => {
      return this.saveDemo(request, response);
    });

    /**
     * @swagger
     * /demo/{id}:
     *   put:
     *     tags:
     *       ['Demo']
     *     summary: Edit demo.
     *     description: Edit the existing demo with id.
     *     consumes:
     *       - application/json
     *     parameters:
     *       - in: path
     *         name: id
     *         description: Demo id requires to change.
     *         required: true
     *         schema:
     *           type: integer
     *           minimum: 1
     *       - in: body
     *         name: body
     *         description: Demo object that needs to be modified to the memory.
     *         required: true
     *         schema:
     *           $ref: '#/definitions/Demo'
     *     responses:
     *       200:
     *         description: OK
     *         schema:
     *           $ref: '#/definitions/Demo'
     *       415:
     *         description: Invalid status value
     */
    app.put('/demo/:id', (request: Request, response: Response) => {
      this.editDemo(Number(request.params.id), request, response);
    });

    /**
     * @swagger
     * /demo/{id}:
     *   delete:
     *     tags:
     *       ['Demo']
     *     summary: Delete demo.
     *     description: Delete the existing demo with id.
     *     parameters:
     *       - in: path
     *         name: id
     *         description: Demo id requires to delete.
     *         required: true
     *         schema:
     *           type: integer
     *           minimum: 1
     *     responses:
     *       200:
     *         description: OK
     */
    app.delete('/demo/:id', (request: Request, response: Response) => {
      return this.deleteDemo(Number(request.params.id), response);
    });
  }
}
