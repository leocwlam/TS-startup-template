import { injectable } from 'inversify';

const WEBCONFIG = require('../../web-config.json');
// eslint-disable-next-line no-unused-vars
import { AppConfig } from './app-config';

@injectable()
export class WebConfig extends AppConfig {
  load(): void {
    throw new Error('Method not implemented.');
  }
  config(): any {
    return WEBCONFIG;
  }
}
