import { injectable } from 'inversify';

const SWAGGERCONFIG = require('../../swagger-config.json');
// eslint-disable-next-line no-unused-vars
import { Config } from './config';

@injectable()
export class SwaggerConfig implements Config {
  load(): void {
    throw new Error('Method not implemented.');
  }
  config(): any {
    return SWAGGERCONFIG;
  }
}
