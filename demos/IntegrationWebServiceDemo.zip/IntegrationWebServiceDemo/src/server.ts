import { Type } from './di.type';
import { container } from './di.config';
// eslint-disable-next-line no-unused-vars
import { AppConfig } from './config/app-config';
// eslint-disable-next-line no-unused-vars
import { AppLogger } from './lib/logger/app-logger';
// eslint-disable-next-line no-unused-vars
import { WebService } from './web-service';

async function start() {
  const appConfig = container.get<AppConfig>(Type.AppConfig).config();
  const logger: AppLogger = container.get<AppLogger>(Type.AppLogger);
  const webService: WebService = container.get<WebService>(Type.WebService);
  logger.isApplyMessageFormat = true;

  logger.log(`Welcome to '${appConfig.name}'`);
  webService.start();
}

start();
