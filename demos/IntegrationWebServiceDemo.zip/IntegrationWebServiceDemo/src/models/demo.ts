/**
 * @swagger
 * definitions:
 *   Demo:
 *     type: object
 *     properties:
 *       id:
 *         type: integer
 *         example: 34
 *       name:
 *         type: string
 *         example: Demo 34
 *     # Both properties are required
 *     required:
 *       - id
 *       - name
 */
export class Demo {
  id!: number;
  name!: string;
}
