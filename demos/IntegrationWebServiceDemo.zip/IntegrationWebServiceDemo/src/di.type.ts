export const Type = {
  AppConfig: Symbol('AppConfig'),
  WebConfig: Symbol('WebConfig'),
  SwaggerConfig: Symbol('SwaggerConfig'),
  AppLogger: Symbol('AppLogger'),
  ExternalLogger: Symbol('ExternalLogger'),
  WebService: Symbol('WebService'),
  DemoController: Symbol('DemoController'),
};
