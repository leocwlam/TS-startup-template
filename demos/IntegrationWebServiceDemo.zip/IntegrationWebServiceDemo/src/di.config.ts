import { Container } from 'inversify';
import 'reflect-metadata';
import { Type } from './di.type';

import { AppConfig } from './config/app-config';
import { WebConfig } from './config/web-config';
import { SwaggerConfig } from './config/swagger-config';
import { AppLogger } from './lib/logger/app-logger';
import { WebService } from './web-service';
import { DemoController } from './controllers/demo-controller';

export const container = new Container();
container.bind<AppConfig>(Type.AppConfig).to(AppConfig);
container.bind<WebConfig>(Type.WebConfig).to(WebConfig);
container.bind<SwaggerConfig>(Type.SwaggerConfig).to(SwaggerConfig);
container.bind<AppLogger>(Type.AppLogger).to(AppLogger);
container.bind<WebService>(Type.WebService).to(WebService);
container.bind<DemoController>(Type.DemoController).to(DemoController);
// eslint-disable-next-line no-console
container.bind(Type.ExternalLogger).toFunction(console.log);
