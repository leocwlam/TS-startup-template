/* eslint-disable no-unused-vars */
import { inject, injectable } from 'inversify';

import express from 'express';
import bodyParser from 'body-parser';

import { setupSwaggerUI } from './swagger';

import { Type } from './di.type';
import { AppConfig } from './config/app-config';
import { WebConfig } from './config/web-config';
import { SwaggerConfig } from './config/swagger-config';
import { AppLogger } from './lib/logger/app-logger';
import * as http from 'http';

import { DemoController } from './controllers/demo-controller';

@injectable()
export class WebService {
  private appConfig: any;
  private webConfig: any;
  private swaggerConfig: any;
  private app: any;
  private logger: AppLogger;
  private webServer: http.Server | undefined;

  private demoController: DemoController;

  constructor(
    @inject(Type.AppConfig) appConfig: AppConfig,
    @inject(Type.WebConfig) webConfig: WebConfig,
    @inject(Type.SwaggerConfig) swaggerConfig: SwaggerConfig,
    @inject(Type.AppLogger) logger: AppLogger,
    @inject(Type.DemoController) demoController: DemoController,
  ) {
    this.appConfig = appConfig.config();
    this.webConfig = webConfig.config();
    this.swaggerConfig = swaggerConfig.config();
    this.logger = logger;
    this.logger.isApplyMessageFormat = true;
    this.demoController = demoController;
    this.init();
  }

  private init() {
    this.app = express();
    this.app.use(bodyParser.urlencoded({ extended: true }));
    this.app.use(bodyParser.json());
    this.app.use(bodyParser.raw());
    this.setupURIMapping();
    setupSwaggerUI(this.swaggerConfig, this.app);
  }

  start() {
    this.webServer = this.app.listen(this.webConfig.port);
    if (!this.webServer) {
      throw new Error('Missing the web server');
    }

    if (this.webConfig.timeout) {
      this.webServer.setTimeout(this.webConfig.timeout);
      this.logger.silly(
        `Overwrite Web Server timeout with ${this.webConfig.timeout}`,
      );
    }
    this.logger.log('Start Web Server');
  }

  private setupURIMapping() {
    this.app.get('/', (req: any, res: any) => {
      res.status(200).send(`Welcome to '${this.appConfig.name}'`);
    });

    if (this.demoController) {
      this.demoController.uriMapping(this.app);
    }
  }
}
