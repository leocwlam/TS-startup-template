const fs = require('fs');
const http = require('http');
import { join as pathJoin } from 'path';

// eslint-disable-next-line no-unused-vars
import { Request, Response } from 'express';
import swaggerJsDoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';

const SWAGGERJSON = '../swagger.json';
const SWAGGERJSONFILE = pathJoin(__dirname, SWAGGERJSON);

// Extended: https://swagger.io/specification/#infoObject
const swaggerJsDocOptions: swaggerJsDoc.Options = {
  openapi: '3.0.0',
  swaggerDefinition: {
    info: {
      title: 'N/A',
      version: 'N/A',
      description: 'N/A',
    },
    host: 'N/A',
    basePath: '/',
    license: {
      name: 'MIT',
      url: 'https://opensource.org/licenses/MIT',
    },
    securityDefinitions: {
      bearerAuth: {
        type: 'apiKey',
        name: 'Authorization',
        scheme: 'bearer',
        in: 'header',
      },
    },
  },
  apis: ['**/controllers/*.ts', '**/models/*.ts'],
};

function getSwaggerDocs(swaggerConfig: any): object {
  if (swaggerJsDocOptions.swaggerDefinition) {
    swaggerJsDocOptions.swaggerDefinition.info = {
      title: swaggerConfig.title,
      version: swaggerConfig.version,
      description: swaggerConfig.description,
    };
    swaggerJsDocOptions.swaggerDefinition.host = swaggerConfig.host;
  }
  return swaggerJsDoc(swaggerJsDocOptions);
}

function updateSwaggerJson(swaggerConfig: any, app: any) {
  http.get(`http://${swaggerConfig.host}/api-docs.json`, function (
    response: any,
  ) {
    let body = '';
    response.on('data', function (d: string) {
      body += d;
    });
    response.on('end', function () {
      fs.writeFile(
        SWAGGERJSONFILE,
        JSON.stringify(JSON.parse(body)),
        async (err: any) => {
          if (err) {
            throw err;
          }
          app.use(
            '/api-docs',
            swaggerUi.serve,
            swaggerUi.setup(require(SWAGGERJSON)),
          );
        },
      );
    });
  });
}

export function setupSwaggerUI(swaggerConfig: any, app: any) {
  if (swaggerConfig.skipUpdateSwaggerJsonFile) {
    app.use(
      '/api-docs',
      swaggerUi.serve,
      swaggerUi.setup(require(SWAGGERJSON)),
    );
  } else {
    const swaggerDocs = getSwaggerDocs(swaggerConfig);

    app.get('/api-docs.json', function (request: Request, response: Response) {
      response.setHeader('Content-Type', 'application/json');
      response.send(swaggerDocs);
    });

    updateSwaggerJson(swaggerConfig, app);
  }
}
