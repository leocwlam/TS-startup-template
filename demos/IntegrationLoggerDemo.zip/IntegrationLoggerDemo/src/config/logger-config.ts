import { injectable } from 'inversify';

// eslint-disable-next-line no-unused-vars
import { level, LoggerConfiguration } from 'system-logger';

@injectable()
export class LoggerConfig implements LoggerConfiguration {
  level: level = level.silly;
  silent?: boolean | undefined = false;
  externalDisplayFormat?: any = undefined;
}
