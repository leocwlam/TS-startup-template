import { Type } from './di.type';
import { container } from './di.config';
// eslint-disable-next-line no-unused-vars
import { AppConfig } from './config/app-config';
// eslint-disable-next-line no-unused-vars
import { AppLogger } from './lib/logger/app-logger';
import * as SystemTask from 'system-task';

const TYPE = 'Demo Task';
const REQUIREASYNCEPROCESS = true;

const DEMOASSET = {
  name: 'DEMO ASSET',
  async execute(message: string) {
    return new Promise((res) => {
      // console.log(`Implement execute aseet logic using ${message}`); // eslint-disable-line no-console

      setTimeout(() => {
        // eslint-disable-next-line no-console
        console.log(`Done with ${message}`);
        res();
      }, 5000);
    });
  },
};

const logMethod = function (
  messageType: string,
  message: string,
  detailMessage?: any,
) {
  // eslint-disable-next-line no-console
  console.log(messageType, message, detailMessage);
};

class DemoTask extends SystemTask {
  constructor() {
    super(TYPE, REQUIREASYNCEPROCESS, logMethod);
  }

  async insertPreprocessItemsHandler(task: DemoTask): Promise<any> {
    if (!task) {
      throw new Error('missing task');
    }
    return [
      { ...DEMOASSET, name: 'Asset 1' },
      { ...DEMOASSET, name: 'Asset 2' },
    ];
  }

  async processHandler(task: DemoTask, processItem: any): Promise<any> {
    await task.log('info', 'execuse', { Type: task.type, processItem });
    // processItem can be execute method
    // e.g.
    await processItem.execute(processItem.name);

    return processItem;
  }
}

async function start() {
  const appConfig = container.get<AppConfig>(Type.AppConfig).config();
  const logger = container.get<AppLogger>(Type.AppLogger);
  logger.isApplyMessageFormat = true;

  logger.log(`Welcome to '${appConfig.name}'`);

  const task: DemoTask = new DemoTask();
  await task.start();
}

start();
