export const Type = {
  AppConfig: Symbol('AppConfig'),
  AppLogger: Symbol('AppLogger'),
  ExternalLogger: Symbol('ExternalLogger'),
};
